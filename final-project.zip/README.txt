08/02/2022

JS Course - Movies API

Full Name: Aharon Achildiev
ID Number: 308338318
Email Address: aharonac@mta.ac.il

Commands to run the project:
npm install
npm run build
npm run app

then in your browser go to : http://localhost:5050

Comments:
- This is a single page application.
- Movie page is a popup.
- no support for delete a movie through the front end application because I didn't have time to implement it.
- Basic styling.