function Logo() {
  return /*#__PURE__*/React.createElement("img", {
    src: "../img/logo.png"
  });
}

export default Logo;