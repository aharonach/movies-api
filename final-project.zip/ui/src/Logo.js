function Logo() {
    return (
        <img src="../img/logo.png" />
    );
}

export default Logo;